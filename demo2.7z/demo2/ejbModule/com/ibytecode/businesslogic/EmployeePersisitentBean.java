package com.ibytecode.businesslogic;

import java.util.List;

@Stateless
public class EmployeePersisitentBean {
	 public void addEmployee(Employee emp) {
	     //persist book using jdbc calls
	   }    

	   public List<Employee> getEmployees() {        
	     //get books using jdbc calls
	   }
}
