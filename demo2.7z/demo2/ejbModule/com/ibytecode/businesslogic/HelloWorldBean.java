package com.ibytecode.businesslogic;

import com.ibytecode.business.HelloWorld;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.ibytecode.businesslogic.Employee;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class HelloWorldBean
 */
@Stateless

public class HelloWorldBean implements HelloWorld {

    
    public void addEmployee(Employee emp) {
    	 Connection con = getConnection();
    	    List<Employee> emps = new ArrayList<Employee>();

         try {


            PreparedStatement st = 
            con.prepareStatement("insert into Employee(name) values(?)");
            st.setString(1,emp.getName());

            int result = st.executeUpdate();                

         } catch (SQLException ex) {
            ex.printStackTrace();
         } catch (InstantiationException ex) {
            ex.printStackTrace();
         } catch (IllegalAccessException ex) {
            ex.printStackTrace();
         } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
         }    
	   }    

	   public List<Employee> getEmployees() {        
		   Connection con = getConnection();
		   
		      List<Employee> emps = new ArrayList<Employee>();
		      try {

		        
		         Statement st = con.createStatement();
		         ResultSet rs = st.executeQuery("select * from Employee");

		         Employee emp;
		         while (rs.next()) {
		        	 emp = new Employee();
		        	 emp.setId(rs.getInt(1));                 
		        	 emp.setName(rs.getString(2));
		            emps.add(emp);
		         }
		      } catch (SQLException ex) {
		         ex.printStackTrace();
		      } catch (InstantiationException ex) {
		         ex.printStackTrace();
		      } catch (IllegalAccessException ex) {
		         ex.printStackTrace();
		      } catch (ClassNotFoundException ex) {
		         ex.printStackTrace();
		      }
		      return emps;
		   }

private Connection getConnection() {
	String url = "jdbc:postgresql://localhost:5432/postgres";
    String driver = "org.postgresql.driver";

    String userName = "postgres";
    String password = "postgres";
    Connection  con =null;
    try {

       Class.forName(driver).newInstance();
         con = DriverManager.getConnection(url , userName, password);
    }catch (SQLException ex) {
        ex.printStackTrace();
     }
    
       return con;

}


}
