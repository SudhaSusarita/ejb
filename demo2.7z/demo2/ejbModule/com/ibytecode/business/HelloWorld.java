package com.ibytecode.business;

import java.util.List;

import javax.ejb.Remote;

import com.ibytecode.businesslogic.Employee;

@Remote
public interface HelloWorld {
	 public void addEmployee(Employee emp) ;

	   public List<Employee> getEmployees();

}
